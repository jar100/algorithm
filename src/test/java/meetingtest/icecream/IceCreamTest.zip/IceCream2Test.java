package programas.icecream;

import org.junit.Test;
import programas.BaseTest;

public class IceCream2Test extends BaseTest {

    @Test
    public void name1() {
        String a = "aaaa";
        System.out.println(        a.indexOf("note"));
    }

    @Test
    public void name2() {

    }

    @Test
    public void name3() {

    }
}