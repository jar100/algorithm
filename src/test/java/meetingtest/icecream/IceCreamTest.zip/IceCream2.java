package programas.icecream;

import java.util.ArrayList;
import java.util.List;

public class IceCream2 {
    public List<String> solution(String[] docs) {
        List<String> answer = new ArrayList<>();
        int startIndex;
        for (String s : answer) {
            if (s.indexOf("note") >= 0) {
                startIndex = s.indexOf("note");
                if (s.indexOf(startIndex -1) = '') {
                    break;
                }
            }
        }
        return answer;
    }


}
